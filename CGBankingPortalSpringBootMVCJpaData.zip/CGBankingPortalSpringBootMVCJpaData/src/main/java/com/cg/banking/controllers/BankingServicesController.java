package com.cg.banking.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {

	@Autowired
	BankingServices bankingServices;
	
	@RequestMapping("/registerAccount")
	public ModelAndView registerAccount(@Valid@ModelAttribute Account account,BindingResult result) {
		if(result.hasErrors())return new ModelAndView("registrationPage");
		account=bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage", "account", account);
	}

	@RequestMapping("/accountDetails")
	public ModelAndView getAccountDetails(@RequestParam long accountNo)throws AccountNotFoundException {
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("findAccountDetailsPage", "account", account);
	}
	@RequestMapping("/allAccountDetails")
	public ModelAndView getallAccountAccountDetails()throws AccountNotFoundException {
		List<Account> accounts=bankingServices.getAllAccountDetails();
		return new ModelAndView("findAllAccountDetailsPage", "accounts", accounts);
	}
	@RequestMapping("/deposit")
	public ModelAndView getDepositAmountDetails(@RequestParam long accountNo,int amount)throws AccountNotFoundException,AccountBlockedException,BankingServiceDownException {
		int total=bankingServices.depositAmount(accountNo, amount);
		return new ModelAndView("getDepositAmountDetailsPage", "total", total);
	}
	@RequestMapping("/fundTransfer")
	public ModelAndView getWithdrawlAmountDetails(@RequestParam long accountNoTo, long acccountNoFrom, int transferAmount, int pinNumber)throws AccountNotFoundException,AccountBlockedException,InvalidPinNumberException,InsufficientAmountException,BankingServiceDownException{
		bankingServices.fundTransfer(accountNoTo, acccountNoFrom, transferAmount, pinNumber);
		ModelAndView ref = new ModelAndView("getFundTransferPage");
		ref.addObject("fund",bankingServices.getAccountDetails(accountNoTo));
		ref.addObject("fund1",bankingServices.getAccountDetails(acccountNoFrom));
		return ref;
	}
	@RequestMapping("/withdrawal")
	public ModelAndView getWithAmountDetails(@RequestParam long accountNo,int amount,int pinNumber)throws AccountNotFoundException,
	 BankingServiceDownException, InvalidPinNumberException, InsufficientAmountException{
		int total=bankingServices.withdrawAmount(accountNo, amount, pinNumber);
		return new ModelAndView("getWithdrawalAmountDetailsPage", "total", total);
	}
}
