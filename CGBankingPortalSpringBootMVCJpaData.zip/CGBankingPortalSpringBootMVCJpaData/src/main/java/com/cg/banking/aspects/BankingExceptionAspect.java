package com.cg.banking.aspects;

import javax.security.auth.login.AccountNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@ControllerAdvice
public class BankingExceptionAspect {

	@ExceptionHandler(AccountNotFoundException.class)
	public ModelAndView handleAccountNotFoundException(Exception e) {
		return new ModelAndView("findAccountDetailsPage", "errorMessage", e.getMessage());
	}
	@ExceptionHandler(AccountBlockedException.class)
	public ModelAndView handleAccountBlockedException(Exception e) {
		return new ModelAndView("findAccountDetailsPage", "errorMessage", e.getMessage());
	}
	@ExceptionHandler(BankingServiceDownException.class)
	public ModelAndView handleBankingServiceDownException(Exception e) {
		return new ModelAndView("findAccountDetailsPage", "errorMessage", e.getMessage());
	}
	@ExceptionHandler(InsufficientAmountException.class)
	public ModelAndView handleInsufficientAmountException(Exception e) {
		return new ModelAndView("findAccountDetailsPage", "errorMessage", e.getMessage());
	}
	@ExceptionHandler(InvalidAccountException.class)
	public ModelAndView handleInvalidAccountException(Exception e) {
		return new ModelAndView("findAccountDetailsPage", "errorMessage", e.getMessage());
	}
	@ExceptionHandler(InvalidAccountTypeException.class)
	public ModelAndView handleInvalidAccountTypeException(Exception e) {
		return new ModelAndView("findAccountDetailsPage", "errorMessage", e.getMessage());
	}
	@ExceptionHandler(InvalidPinNumberException.class)
	public ModelAndView handlePinNumberException(Exception e) {
		return new ModelAndView("findAccountDetailsPage", "errorMessage", e.getMessage());
	}
}
