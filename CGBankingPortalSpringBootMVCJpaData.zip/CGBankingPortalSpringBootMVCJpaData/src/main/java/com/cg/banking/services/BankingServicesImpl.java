package com.cg.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices{
	private   static int count=0;
@Autowired
	private AccountDAO accountDao;
@Autowired
private TransactionDAO transactionDao;
	@Override
	public Account openAccount(Account account) {
		account.setPinNumber((int) (Math.random()*1000));
		return accountDao.save(account);
	}
	
	@Override
	public Account getAccountDetails(long accountNo)throws AccountNotFoundException {
	return accountDao.findById(accountNo).orElseThrow(()->new AccountNotFoundException("account not found "+accountNo));
	
	}
	@Override
	public int depositAmount(long accountNo, int amount) throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("Your account is blocked");
		else
			account.setAccountBalance(account.getAccountBalance()+amount);
		transactionDao.save(new Transaction(amount, "deposit", account));
		accountDao.save(account);
		return account.getAccountBalance();
	}

	public int withdrawAmount(long accountNo, int amount, int pinNumber) throws AccountNotFoundException,
		BankingServiceDownException, InvalidPinNumberException, InsufficientAmountException{
		Account account=getAccountDetails(accountNo);
		
		 if(account.getPinNumber()!=pinNumber)
		 {
			 ++count;
			 if(count==3)account.setAccountStatus("Blocked");
		 }
		 if(account.getAccountBalance()-amount<500)throw new InsufficientAmountException();
		else
			account.setAccountBalance(account.getAccountBalance()-amount);
		accountDao.save(account);
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long acccountNoFrom, int transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServiceDownException, AccountBlockedException {
		Account customerNoTo=getAccountDetails(accountNoTo);
		Account customerNoFrom=getAccountDetails(acccountNoFrom);
		if(customerNoTo.getAccountStatus().equalsIgnoreCase("Blocked")||customerNoFrom.getAccountStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("Account is Blocked");
		else if(customerNoFrom.getPinNumber()!=pinNumber)throw new InvalidPinNumberException("Pin is Invalid");
		else if(customerNoFrom.getAccountBalance()-transferAmount<500)throw new InsufficientAmountException("Amount is Insufficient in Account");
		else {
			customerNoTo.setAccountBalance(customerNoTo.getAccountBalance()+transferAmount);
		    transactionDao.save(new Transaction(transferAmount, "deposit", customerNoTo));
			accountDao.save(customerNoTo);
			customerNoFrom.setAccountBalance(customerNoFrom.getAccountBalance()-transferAmount);
			transactionDao.save(new Transaction(transferAmount, "withdraw", customerNoFrom));
			accountDao.save(customerNoFrom);
		}	
	return true;
	}

@Override
	public List<Account> getAllAccountDetails() throws AccountNotFoundException {
		return accountDao.findAll();
	}
	@Override
	public List<Transaction> getAccountAllTransactions(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException {
		return transactionDao.findallTxns(accountNo);
		
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("Account is blocked");
		else
		return "active";
	}
}

	

