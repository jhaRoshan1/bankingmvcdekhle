package com.cg.payroll.aspects;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.customes.CustomResponse;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
@ControllerAdvice
public class PayrollExceptionAspect {

	@ExceptionHandler(AssociateDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse> handleAssociateDetailsNotFoundException(Exception e) {
		CustomResponse response=new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
}
